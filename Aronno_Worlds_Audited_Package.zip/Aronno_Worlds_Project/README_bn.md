# অরণ্য Worlds — C++ Android প্রজেক্ট (পরীক্ষামূলক ০.৪)

এই ফোল্ডার শুধু প্রজেক্ট/source; **এই ধাপের জন্য কোনো APK তৈরি করা হয়নি।** আগের ধাপের অরণ্য ফাইল অপরিবর্তিত আছে। এটি Minecraft বা Unreal-এর কোড নয়; আগের অরণ্যের মতো বাস্তবধর্মী পরিবেশ রেখে world তৈরির ভিত্তি যোগ করা হয়েছে।

## এখন যা কাজ করে
- নতুন home lobby, তৈরি হওয়া world-এর তালিকা, চারটি করে পেজ, `CREATE WORLD`, নাম ও সংখ্যার seed নির্ধারণের জন্য অন-স্ক্রিন keyboard, এবং `CREATE AND PLAY`। নাম বর্তমানে ইংরেজি অক্ষর/সংখ্যা/space, সর্বোচ্চ ১৮ অক্ষর; seed ০ থেকে ৯৯৯৯৯৯৯৯৯।
- প্রতিটি world-এর আলাদা ID, seed, player position, inventory, vitals, কাটা গাছ ও তৈরি shelter-এর save। লবিতে ফিরে অন্য world খোলা যায়। গেমে `M → SAVE AND LOBBY`।
- World-এর জমি ও গাছ seed দিয়ে deterministic ভাবে তৈরি হয়। প্লেয়ার ৩২-unit অংশ পেরিয়ে গেলে কাছাকাছি নতুন ৫×৫ অংশ তৈরি এবং দূরের অংশের mesh পুনর্ব্যবহার হয়; আগে কাটা গাছ ফিরে আসে না। একই seed ও একই অবস্থানে একই ভূখণ্ড পাওয়া যায়।
- পূর্ববর্তী পরীক্ষামূলক গেমের দিন/রাতের সরল আলো, কাছের গাছ কাটা, ঝোপে ফল খোঁজা, কুয়া/নদীতে পানি পান, ছোট shelter তৈরি ও দুজন প্রাথমিক গ্রামবাসী আছে। লবির background আলাদা AI-generated artwork; তা gameplay-এর বাস্তব graphics নয়।
- Save-এর checksum, atomic write ও আগের ভালো কপির backup আছে। নষ্ট save-এর সঙ্গে backup-ও অপাঠযোগ্য হলে world খোলা হয় না, যাতে সেটি অনিচ্ছায় overwrite না হয়। কিছু সাম্প্রতিক অগ্রগতি backup-এ নাও থাকতে পারে।

## খুব গুরুত্বপূর্ণ সীমাবদ্ধতা
- **গণিতের অর্থে অসীম নয়।** চলার সময় অংশ তৈরি হয়, কিন্তু এই সংস্করণে x ও z প্রতিটি দিক ±১০,০০,০০০ game unit-এ সীমিত; float precision, storage এবং memory-ও বাস্তব সীমা। খুব বড় দূরত্বে দৃশ্যের নির্ভুলতা কমতে পারে।
- Minecraft-এর সব world feature এখনও নেই। বড় biome বৈচিত্র্য, গুহা, আকরিক/mining, সঠিক crafting/inventory, প্রাণী ও শত্রু/mobs, জটিল গ্রাম/structures, weather, underground, multiplayer, dimensions এবং আরও অনেক কিছু বাস্তবায়ন করা হয়নি। বর্তমানে মূলত মাঠ, জঙ্গল, একটি গ্রাম ও একটি নদীর ভিত্তি আছে।
- পুরোনো HTML এবং আগের native একক-world save নতুন world-এ import করা হয় না। আগের অ্যাপের save ফাইল মুছে ফেলার কোনো কাজ এই source করে না; কিন্তু এই নতুন lobby-তে সেই save খোলার ব্যবস্থাও নেই। World delete, rename ও export/import UI এখনও নেই।
- লবির চিত্র কল্পনামূলক; চলমান গেম এখনও ছবির মতো photorealistic নয়। UI ইংরেজি। Device অনুযায়ী কন্ট্রোল, graphics, FPS, GPU compatibility ও গরম হওয়া ভিন্ন হতে পারে।
- Android ফোন বা emulator-এ install/runtime পরীক্ষা করা হয়নি। ARM64/ARM32 native C++ library আলাদাভাবে compile/link এবং desktop Mesa OpenGL ES 2 host render ও কোডের স্বয়ংক্রিয় পরীক্ষা হয়েছে। এগুলো Android পরীক্ষা নয়।

## ব্যবহার (ভবিষ্যতে APK build করা হলে)
লবিতে `CREATE WORLD`; নাম/seed ঠিক করে `CREATE AND PLAY`। আগে বানানো world খুলতে `PLAY WORLDS`। গেমে বাম joystick চলা, খালি জায়গায় টেনে ৩৬০° অনুভূমিক camera, J লাফ, A গাছ কাটার একটি আঘাত (তিন আঘাত), M মেনু। ফলের ঝোপে গিয়ে `FORAGE`; ফল তুললে ২০ সেকেন্ড বিরতি। `SAVE AND LOBBY` বর্তমান world সংরক্ষণ করে তালিকায় ফেরে।

## প্রজেক্ট Build
Android Studio, JDK 17, Android SDK platform 33, NDK এবং CMake 3.22.1 দিয়ে প্রজেক্টটি খুলুন। Gradle route এখনও পরীক্ষা করা হয়নি। `build_apk.sh` ঐচ্ছিক Linux manual build script; ব্যবহার করলে APK তৈরি হবে—এই ধাপে তা চালানো হয়নি। Script-এ SDK/NDK path environment variables লাগবে। প্রজেক্টে কোনো signing key নেই; অন্য key ব্যবহার করলে পূর্ববর্তী APK-এর ওপর update হিসেবে install নাও হতে পারে। Release-এর জন্য নিজস্ব সুরক্ষিত release key প্রয়োজন।

Standalone world test:
```sh
g++ -std=c++17 -O2 tests/world_test.cpp -o /tmp/world_test && /tmp/world_test
```

## উপকরণ
Lobby image: এই প্রজেক্টের জন্য AI-generated artwork। Player এবং সরলীকৃত NPC: Grab3D AI-assisted Man Base Mesh (CC0); `app/src/main/assets/PLAYER_LICENSE.txt`। প্রকৃতি ও ঘরের ছবিভিত্তিক texture: Poly Haven (CC0)। `vendor/cgltf.h` MIT ও `vendor/stb_image.h` MIT/public-domain বিকল্প স্ব স্ব header-এ আছে। Gradle wrapper Apache 2.0। `docs/`-এর দুটি ছবি desktop host render থেকে নেওয়া; ফোনের screenshot নয়।
