#include "../app/src/main/cpp/world_store.h"
#include <cassert>
#include <cmath>
#include <cstdlib>
#include <iostream>
int main(){
 char dir[]="/tmp/aronno-worlds-test-XXXXXX";assert(mkdtemp(dir));std::string root=dir;using namespace WorldStore;
 Meta a,b;assert(!create(root,"../bad",1,a));assert(create(root,"GREEN HILLS",123456,a));assert(create(root,"SECOND WORLD",987654,b));assert(a.id!=b.id&&a.seed!=b.seed);auto list1=list(root);assert(list1.size()==2);
 auto pathA=WorldStore::root(root)+"/"+a.id,pathB=WorldStore::root(root)+"/"+b.id;GameState g;assert(load(pathA,a.seed,g)==PRIMARY&&g.wood==0);
 g.x=5200;g.z=-4300;g.refreshTrees();assert(g.trees.size()>100);float h=GameState::height(g.x,g.z);auto first=g.trees[0];uint64_t key=GameState::treeKey(first.cellX,first.cellZ);g.felled.insert(key);g.wood=15;g.berries=3;g.forageReadyAt=90;g.shelters.push_back({5202,-4298});assert(save(pathA,g));g.wood=16;assert(save(pathA,g));
 GameState other;assert(load(pathB,b.seed,other)==PRIMARY&&other.wood==0&&other.felled.empty());GameState check;assert(load(pathA,a.seed,check)==PRIMARY&&check.wood==16&&check.felled.count(key)&&check.x==5200&&check.shelters.size()==1&&check.forageReadyAt==90);
 bool found=false;for(auto&t:check.trees)if(GameState::treeKey(t.cellX,t.cellZ)==key){found=true;assert(t.harvested);}assert(found);assert(std::fabs(GameState::height(5200,-4300)-h)<1e-5f);
 check.x=0;check.z=0;check.refreshTrees();check.x=5200;check.z=-4300;check.refreshTrees();found=false;for(auto&t:check.trees)if(GameState::treeKey(t.cellX,t.cellZ)==key){found=true;assert(t.harvested);}assert(found);
 // Same seed produces the same tree positions even after unloading; different seeds vary terrain.
 GameState repeat;repeat.initialize(a.seed);repeat.x=5200;repeat.z=-4300;repeat.refreshTrees();assert(repeat.trees[0].cellX==first.cellX&&repeat.trees[0].cellZ==first.cellZ&&repeat.trees[0].x==first.x);GameState diff;diff.initialize(b.seed);assert(std::fabs(GameState::height(5200,-4300)-h)>.001f);
 Bytes damaged;assert(read(pathA+"/world.dat",damaged)==1);damaged[20]^=0x55;assert(atomicWrite(pathA+"/world.dat",damaged));assert(load(pathA,a.seed,check)==BACKUP&&check.wood==15);assert(atomicWrite(pathA+"/world.bak",damaged));assert(load(pathA,a.seed,check)==BLOCKED);
 // Negative coordinates and ordinary world-boundary crossing.
 GameState move;move.initialize(44);move.x=-5000;move.z=-5000;move.refreshTrees();float x=move.x;move.cameraYaw=0;for(int i=0;i<20;i++)move.tick(.05f,1,0,false);assert(move.x>x);assert(move.x< -4997);assert(move.chunkX==GameState::chunk(move.x));
 std::cout<<"world creation, isolation, deterministic streaming, unload/reload, negative coordinates, backup and corruption passed\n";
}
