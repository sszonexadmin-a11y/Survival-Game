#pragma once
#include "game_state.h"
#include <algorithm>
#include <cerrno>
#include <cstring>
#include <cstdio>
#include <string>
#include <vector>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>

namespace WorldStore {
using Bytes=std::vector<uint8_t>;
inline void put32(Bytes&b,uint32_t v){for(int i=0;i<4;i++)b.push_back(uint8_t(v>>(i*8)));}
inline bool get32(const Bytes&b,size_t&p,uint32_t&v){if(p+4>b.size())return false;v=0;for(int i=0;i<4;i++)v|=uint32_t(b[p++])<<(i*8);return true;}
inline void putFloat(Bytes&b,float f){uint32_t u;std::memcpy(&u,&f,4);put32(b,u);}
inline bool getFloat(const Bytes&b,size_t&p,float&f){uint32_t u;if(!get32(b,p,u))return false;std::memcpy(&f,&u,4);return std::isfinite(f);}
inline uint32_t crc32(const Bytes&b,size_t end){uint32_t c=~0u;for(size_t i=0;i<end;i++){c^=b[i];for(int j=0;j<8;j++)c=(c>>1)^(0xedb88320u&(0u-(c&1u)));}return ~c;}
inline void seal(Bytes&b){put32(b,crc32(b,b.size()));}
inline bool validCRC(const Bytes&b){if(b.size()<4)return false;size_t p=b.size()-4;uint32_t crc;return get32(b,p,crc)&&crc==crc32(b,b.size()-4);}
// Missing=0, read=1, unreadable/invalid length=-1.
inline int read(const std::string&path,Bytes&b){FILE*f=std::fopen(path.c_str(),"rb");if(!f)return errno==ENOENT?0:-1;if(std::fseek(f,0,SEEK_END)){std::fclose(f);return -1;}long n=std::ftell(f);if(n<0||n>16*1024*1024||std::fseek(f,0,SEEK_SET)){std::fclose(f);return -1;}b.resize(size_t(n));bool ok=!n||std::fread(b.data(),1,b.size(),f)==b.size();if(std::fclose(f))ok=false;return ok?1:-1;}
inline bool atomicWrite(const std::string&path,const Bytes&b){std::string tmp=path+".tmp";FILE*f=std::fopen(tmp.c_str(),"wb");if(!f)return false;bool ok=std::fwrite(b.data(),1,b.size(),f)==b.size();if(ok)ok=std::fflush(f)==0;if(ok)ok=fsync(fileno(f))==0;if(std::fclose(f))ok=false;if(ok)ok=std::rename(tmp.c_str(),path.c_str())==0;if(!ok)std::remove(tmp.c_str());return ok;}
inline Bytes encode(const GameState&g){Bytes b;put32(b,0x574f524c);put32(b,1);put32(b,g.seed);for(float v:{g.x,g.z,g.yaw,g.cameraYaw,g.cameraPitch,g.health,g.hunger,g.thirst,g.time,g.forageReadyAt})putFloat(b,v);put32(b,g.wood);put32(b,g.berries);put32(b,uint32_t(g.felled.size()));for(uint64_t key:g.felled){put32(b,uint32_t(key>>32));put32(b,uint32_t(key));}put32(b,uint32_t(g.shelters.size()));for(auto&a:g.shelters){putFloat(b,a.x);putFloat(b,a.z);}seal(b);return b;}
inline bool decode(const Bytes&b,uint32_t expected,GameState&out){
 if(b.size()<72||!validCRC(b))return false;
 size_t p=0;uint32_t magic,version,seed,wood,berries,n,m;if(!get32(b,p,magic)||magic!=0x574f524c||!get32(b,p,version)||version!=1||!get32(b,p,seed)||seed!=expected)return false;
 float v[10];for(float&f:v)if(!getFloat(b,p,f))return false;if(std::fabs(v[0])>1000000||std::fabs(v[1])>1000000||v[5]<0||v[5]>100||v[6]<0||v[6]>100||v[7]<0||v[7]>100||v[8]<0||v[8]>100000000.f||v[9]<0||v[9]>100000020.f)return false;
 if(!get32(b,p,wood)||wood>100000||!get32(b,p,berries)||berries>99||!get32(b,p,n)||n>100000||p+size_t(n)*8>b.size())return false;
 GameState g;g.initialize(seed);g.x=v[0];g.z=v[1];g.yaw=std::remainder(v[2],6.2831853f);g.cameraYaw=std::remainder(v[3],6.2831853f);g.cameraPitch=GameState::clampf(v[4],-.15f,1.15f);g.health=v[5];g.hunger=v[6];g.thirst=v[7];g.time=v[8];g.forageReadyAt=v[9];g.wood=wood;g.berries=berries;
 for(uint32_t i=0;i<n;i++){uint32_t hi,lo;if(!get32(b,p,hi)||!get32(b,p,lo))return false;g.felled.insert((uint64_t(hi)<<32)|lo);}if(!get32(b,p,m)||m>20)return false;
 for(uint32_t i=0;i<m;i++){float x,z;if(!getFloat(b,p,x)||!getFloat(b,p,z)||std::fabs(x)>1000000||std::fabs(z)>1000000)return false;g.shelters.push_back({x,z});}if(p+4!=b.size())return false;g.chunkX=g.chunkZ=std::numeric_limits<int>::min();g.refreshTrees();out=std::move(g);return true;
}
enum LoadResult{PRIMARY,BACKUP,BLOCKED};
inline LoadResult load(const std::string&dir,uint32_t seed,GameState&g){Bytes b;GameState out;if(read(dir+"/world.dat",b)==1&&decode(b,seed,out)){g=std::move(out);return PRIMARY;}if(read(dir+"/world.bak",b)==1&&decode(b,seed,out)){g=std::move(out);return BACKUP;}return BLOCKED;}
inline bool save(const std::string&dir,const GameState&g){if(g.felled.size()>100000||g.shelters.size()>20)return false;Bytes old;int status=read(dir+"/world.dat",old);if(status<0)return false;GameState temp;if(status==1&&decode(old,g.seed,temp)&&!atomicWrite(dir+"/world.bak",old))return false;return atomicWrite(dir+"/world.dat",encode(g));}
struct Meta{std::string id,name;uint32_t seed;};
inline bool validName(const std::string&name){if(name.empty()||name.size()>18)return false;for(char c:name)if(!((c>='A'&&c<='Z')||(c>='0'&&c<='9')||c==' '||c=='-'))return false;return true;}
inline Bytes encodeMeta(const Meta&m){Bytes b;put32(b,0x41524d54);put32(b,1);put32(b,m.seed);put32(b,uint32_t(m.name.size()));b.insert(b.end(),m.name.begin(),m.name.end());seal(b);return b;}
inline bool decodeMeta(const Bytes&b,Meta&m){if(b.size()<20||b.size()>64||!validCRC(b))return false;size_t p=0;uint32_t magic,version,len,seed;if(!get32(b,p,magic)||magic!=0x41524d54||!get32(b,p,version)||version!=1||!get32(b,p,seed)||!get32(b,p,len)||len>18||p+len+4!=b.size())return false;std::string name(b.begin()+p,b.begin()+p+len);if(!validName(name))return false;m.name=name;m.seed=seed;return true;}
inline bool validId(const std::string&id){if(id.size()!=10||id.substr(0,2)!="w_")return false;for(int i=2;i<10;i++)if(!((id[i]>='0'&&id[i]<='9')||(id[i]>='a'&&id[i]<='f')))return false;return true;}
inline std::string root(const std::string&base){return base+"/aronno-worlds";}
inline std::vector<Meta> list(const std::string&base){std::vector<Meta> out;auto path=root(base);DIR*d=opendir(path.c_str());if(!d)return out;while(dirent*e=readdir(d)){std::string id=e->d_name;if(!validId(id))continue;Bytes b;Meta m;if(read(path+"/"+id+"/meta.dat",b)==1&&decodeMeta(b,m)){m.id=id;out.push_back(m);}}closedir(d);std::sort(out.begin(),out.end(),[](const Meta&a,const Meta&b){return a.id>b.id;});return out;}
inline bool create(const std::string&base,const std::string&name,uint32_t seed,Meta&out){if(!validName(name))return false;auto r=root(base);if(mkdir(r.c_str(),0700)&&errno!=EEXIST)return false;for(uint32_t i=1;i<1000000;i++){char id[11];std::snprintf(id,sizeof(id),"w_%08x",i);std::string dir=r+"/"+id;if(mkdir(dir.c_str(),0700)){if(errno==EEXIST)continue;return false;}Meta m{id,name,seed};GameState g;g.initialize(seed);if(!atomicWrite(dir+"/meta.dat",encodeMeta(m))||!save(dir,g)){std::remove((dir+"/meta.dat").c_str());std::remove((dir+"/world.dat").c_str());rmdir(dir.c_str());return false;}out=m;return true;}return false;}
}
