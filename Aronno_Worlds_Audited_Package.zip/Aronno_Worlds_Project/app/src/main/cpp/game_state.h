#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <vector>
#include <unordered_set>
#include <limits>

struct Tree { float x,z; bool harvested; int cellX=0,cellZ=0; };
struct Shelter { float x,z; };
struct GameState {
    float x=0,z=14, yaw=0, cameraYaw=0, cameraPitch=.40f;
    float health=100, hunger=100, thirst=100, time=60, jump=0, jumpVelocity=0;
    int wood=0, berries=0;
    float forageReadyAt=0, chopTimer=0;int chopTarget=-1, damageTree=-1, treeHits=0, chopEvent=0, lastFelled=-1;bool chopImpact=false;
    inline static uint32_t worldSeed=1;
    uint32_t seed=1;int chunkX=std::numeric_limits<int>::min(),chunkZ=std::numeric_limits<int>::min();int treeRevision=0;
    std::unordered_set<uint64_t> felled;
    std::vector<Tree> trees;
    std::vector<Shelter> shelters;
    static float clampf(float v,float a,float b){ return std::max(a,std::min(b,v)); }
    static uint32_t hash(int x,int z,int seed){uint32_t n=uint32_t(x)*374761393u+uint32_t(z)*668265263u+uint32_t(seed)*69069u;n=(n^(n>>13))*1274126177u;return n^(n>>16);}
    static float rnd(int x,int z,int seed){ return float(hash(x,z,seed)&0xffffffu)/16777215.f; }
    static float riverX(float z){return 39.f+8.f*std::sin(z*.024f+float(worldSeed%37)*.1f);}
    static bool riverAt(float x,float z){return std::fabs(x-riverX(z))<3.2f;}
    // A finite demonstration area. Heights are deterministic, with a flattened village at the centre.
    static float height(float x,float z){
      float d=std::sqrt(x*x+z*z); float m=clampf((d-18.f)/20.f,0,1);m=m*m*(3-2*m);
      float phase=float(worldSeed%997)*.041f;float h=m*(2.4f*std::sin(x*.018f+phase)*std::cos(z*.019f-phase)+1.1f*std::sin(z*.055f+phase)+.35f*std::sin((x+z)*.14f));
      float blend=clampf((6.5f-std::fabs(x-riverX(z)))/3.f,0,1);blend=blend*blend*(3-2*blend);
      return h*(1-blend)-.55f*blend;
    }
    static uint64_t treeKey(int cx,int cz){return (uint64_t(uint32_t(cx))<<32)|uint32_t(cz);}
    static int chunk(float v){return int(std::floor(v/32.f));}
    void initialize(uint32_t s=1){seed=s;worldSeed=s;trees.clear();felled.clear();chunkX=chunkZ=std::numeric_limits<int>::min();refreshTrees();}
    void refreshTrees(){int cx=chunk(x),cz=chunk(z);if(cx==chunkX&&cz==chunkZ)return;chunkX=cx;chunkZ=cz;trees.clear();chopTimer=0;chopTarget=damageTree=-1;treeHits=0;
      int minX=int(std::floor(((cx-3)*32.f)/5.f))-1,maxX=int(std::ceil(((cx+4)*32.f)/5.f))+1;
      int minZ=int(std::floor(((cz-3)*32.f)/5.f))-1,maxZ=int(std::ceil(((cz+4)*32.f)/5.f))+1;
      for(int a=minX;a<=maxX;a++)for(int b=minZ;b<=maxZ;b++){
       int sd=int(seed);float tx=a*5.f+(rnd(a,b,sd^1)-.5f)*3.f,tz=b*5.f+(rnd(a,b,sd^2)-.5f)*3.f;
       if(tx*tx+tz*tz<22.f*22.f||rnd(a,b,sd^3)>.48f||riverAt(tx,tz))continue;
       trees.push_back({tx,tz,felled.count(treeKey(a,b))!=0,a,b});
      }treeRevision++;
    }
    // The visible walls have a central doorway on the positive-Z side.
    static bool circleRect(float x,float z,float radius,float x0,float z0,float x1,float z1){
      float dx=x-clampf(x,x0,x1),dz=z-clampf(z,z0,z1);return dx*dx+dz*dz<radius*radius;
    }
    static bool houseWalls(float x,float z,float r){
      const float hx[]={-10,10,0},hz[]={-5,-5,-15};
      for(int i=0;i<3;i++){float a=hx[i],b=hz[i];
        if(circleRect(x,z,r,a-3.1f,b-2.6f,a+3.1f,b-2.4f)||
           circleRect(x,z,r,a-3.1f,b-2.6f,a-2.9f,b+2.6f)||
           circleRect(x,z,r,a+2.9f,b-2.6f,a+3.1f,b+2.6f)||
           circleRect(x,z,r,a-3.0f,b+2.4f,a-1.0f,b+2.6f)||
           circleRect(x,z,r,a+1.0f,b+2.4f,a+3.0f,b+2.6f)) return true;
      }return false;
    }
    bool blocked(float px,float pz,float radius=.34f)const{
      if(px< -1000000||px>1000000||pz< -1000000||pz>1000000||houseWalls(px,pz,radius))return true;
      if(circleRect(px,pz,radius,-1.2f,-1.2f,1.2f,1.2f))return true;
      for(const auto&t:trees)if(!t.harvested&&!riverAt(t.x,t.z)){float dx=px-t.x,dz=pz-t.z,rr=radius+.19f;if(dx*dx+dz*dz<rr*rr)return true;}
      for(const auto&s:shelters)if(circleRect(px,pz,radius,s.x-.95f,s.z-.95f,s.x+.95f,s.z+.95f))return true;
      return false;
    }
    bool cameraBlocked(float px,float py,float pz)const{
      if(py<height(px,pz)+.18f)return true;
      if(py<3.45f&&houseWalls(px,pz,.15f))return true;
      // Approximate roof volume: keep the third-person camera out of the roof.
      const float hx[]={-10,10,0},hz[]={-5,-5,-15};
      for(int i=0;i<3;i++)if(py>=3.3f&&py<4.8f&&std::fabs(px-hx[i])<3.35f&&std::fabs(pz-hz[i])<2.85f)return true;
      if(py<.95f&&circleRect(px,pz,.12f,-1.2f,-1.2f,1.2f,1.2f))return true;
      for(const auto&t:trees)if(!t.harvested&&!riverAt(t.x,t.z)&&py<height(t.x,t.z)+4.f){float dx=px-t.x,dz=pz-t.z;if(dx*dx+dz*dz<.30f*.30f)return true;}
      for(const auto&s:shelters)if(py<height(s.x,s.z)+2.3f&&circleRect(px,pz,.12f,s.x-.95f,s.z-.95f,s.x+.95f,s.z+.95f))return true;
      return false;
    }
    // Sample from target towards the camera to prevent the camera passing through walls.
    float cameraDistance(float tx,float ty,float tz,float ex,float ey,float ez)const{
      float dx=ex-tx,dy=ey-ty,dz=ez-tz;const int steps=40;
      for(int i=1;i<=steps;i++){float t=float(i)/steps;if(cameraBlocked(tx+dx*t,ty+dy*t,tz+dz*t))return std::max(.05f,t-1.f/steps);}
      return 1.f;
    }
    bool lineOfSight(float ax,float az,float bx,float bz)const{
      for(int k=1;k<20;k++){float t=k/20.f;if(houseWalls(ax+(bx-ax)*t,az+(bz-az)*t,.02f))return false;}
      return true;
    }
    void tick(float dt,float mx,float my,bool running){
      dt=clampf(dt,0,.05f); float len=std::sqrt(mx*mx+my*my);if(len>1){mx/=len;my/=len;len=1;}
      if(len>.05f){
        float fx=-std::sin(cameraYaw),fz=-std::cos(cameraYaw),rx=std::cos(cameraYaw),rz=-std::sin(cameraYaw);
        float dx=fx*my+rx*mx,dz=fz*my+rz*mx;float speed=running?5.f:2.8f;
        float nx=clampf(x+dx*speed*dt,-1000000.f,1000000.f),nz=clampf(z+dz*speed*dt,-1000000.f,1000000.f);
        // Separate axes allow natural sliding; old saves inside a wall can escape.
        if(!blocked(nx,z)||blocked(x,z))x=nx;
        if(!blocked(x,nz)||blocked(x,z))z=nz;
        yaw=std::atan2(-dx,-dz);refreshTrees();
      }
      if(jump>0||jumpVelocity>0){jumpVelocity-=11.f*dt;jump+=jumpVelocity*dt;if(jump<0){jump=0;jumpVelocity=0;}}
      if(chopTimer>0){chopTimer=std::max(0.f,chopTimer-dt);if(!chopImpact&&chopTimer<=.18f){chopImpact=true;if(chopTarget>=0&&targetTree()==chopTarget){if(damageTree!=chopTarget){damageTree=chopTarget;treeHits=0;}treeHits++;chopEvent=1;if(treeHits>=3){trees[chopTarget].harvested=true;felled.insert(treeKey(trees[chopTarget].cellX,trees[chopTarget].cellZ));wood++;lastFelled=chopTarget;treeHits=0;damageTree=-1;chopEvent=2;}}else chopEvent=-1;}}
      time+=dt;hunger=std::max(0.f,hunger-.035f*dt);thirst=std::max(0.f,thirst-.05f*dt);
      if(hunger<=0||thirst<=0)health=std::max(0.f,health-.18f*dt);else if(hunger>40&&thirst>40)health=std::min(100.f,health+.02f*dt);
      if(health<=0){x=0;z=14;health=100;hunger=thirst=60;jump=jumpVelocity=0;}
    }
    void turnCamera(float dx,float dy,float viewWidth,float viewHeight){
      if(viewWidth<=0||viewHeight<=0)return;
      cameraYaw=std::remainder(cameraYaw-dx*(6.2831853f/viewWidth),6.2831853f);
      cameraPitch=clampf(cameraPitch+dy*(3.0f/viewHeight),-.15f,1.15f);
    }
    void jumpNow(){if(jump<=0)jumpVelocity=4.7f;}
    // Returns index of a nearby tree in front, or -1. Collision and distance are kept in sync.
    int targetTree() const {
      int best=-1;float bd=3.25f*3.25f;float fx=-std::sin(yaw),fz=-std::cos(yaw);
      for(int i=0;i<(int)trees.size();i++){
        const auto&t=trees[i];if(t.harvested||riverAt(t.x,t.z))continue;float dx=t.x-x,dz=t.z-z,d2=dx*dx+dz*dz;
        if(d2<bd && dx*fx+dz*fz>0.3f*std::sqrt(d2) && lineOfSight(x,z,t.x,t.z)){bd=d2;best=i;}
      }return best;
    }
    bool chop(){int i=targetTree();if(i<0||chopTimer>0||felled.size()>=100000||wood>=100000)return false;chopTarget=i;chopImpact=false;chopTimer=.72f;return true;}
    static bool nearBush(float x,float z){const float bx[]={3,16,-17,21,-24,10},bz[]={10,6,6,14,15,24};for(int i=0;i<6;i++){float dx=x-bx[i],dz=z-bz[i];if(dx*dx+dz*dz<3.f*3.f)return true;}return false;}
    bool forage(){if(berries>=99||time<forageReadyAt||!nearBush(x,z))return false;berries++;forageReadyAt=time+20.f;return true;}
    bool eat(){if(!berries)return false;berries--;hunger=std::min(100.f,hunger+25.f);return true;}
    bool drink(){if(x*x+z*z>4.f*4.f&&std::fabs(x-riverX(z))>5.f)return false;thirst=std::min(100.f,thirst+35.f);return true;}
    bool build(){if(wood<5||shelters.size()>=20)return false;float sx=x+2.f,sz=z+2.f;if(blocked(sx,sz,1.4f)||sx< -999998||sx>999998||sz< -999998||sz>999998)return false;wood-=5;shelters.push_back({sx,sz});return true;}
    bool rest(){for(auto&s:shelters)if((s.x-x)*(s.x-x)+(s.z-z)*(s.z-z)<3.5f*3.5f){health=std::min(100.f,health+25.f);return true;}return false;}
};
