#pragma once
#include <android/asset_manager.h>
#include <android/native_activity.h>
#include <GLES2/gl2.h>
#include <cmath>
#include <vector>
#include <string>

// An optimized Grab3D CC0 (AI-assisted) skinned character, loaded from a local GLB.
// Model data and textures stay on-device; no network requests are made.
struct PlayerVertex{float p[3],n[3],uv[2],joint[4],weight[4];};
struct PlayerModel {
 std::vector<unsigned char> blob;cgltf_data* data=nullptr;cgltf_skin* skin=nullptr;cgltf_animation *walk=nullptr,*run=nullptr;GLuint programId=0,vbo=0,texture=0;size_t count=0;float clock=0;bool ready=false;Mat handWorld;
 ~PlayerModel(){release();}
 void release(){if(vbo)glDeleteBuffers(1,&vbo);if(texture)glDeleteTextures(1,&texture);if(programId)glDeleteProgram(programId);vbo=texture=programId=0;if(data)cgltf_free(data);data=nullptr;skin=nullptr;walk=run=nullptr;blob.clear();ready=false;}
 static GLuint compile(GLenum kind,const char*s){GLuint id=glCreateShader(kind);glShaderSource(id,1,&s,nullptr);glCompileShader(id);GLint ok;glGetShaderiv(id,GL_COMPILE_STATUS,&ok);if(!ok){char msg[512];glGetShaderInfoLog(id,sizeof(msg),nullptr,msg);__android_log_print(ANDROID_LOG_ERROR,"AronnoNative","character shader %s",msg);glDeleteShader(id);return 0;}return id;}
 static GLuint makeProgram(){
  const char*vs="attribute vec3 aPos;attribute vec3 aNormal;attribute vec2 aUV;attribute vec4 aJoint;attribute vec4 aWeight;uniform mat4 uMVP;uniform mat4 uModel;uniform mat4 uBones[24];uniform float uDay;varying vec2 vUV;varying float vLight;void main(){mat4 s=aWeight.x*uBones[int(aJoint.x)]+aWeight.y*uBones[int(aJoint.y)]+aWeight.z*uBones[int(aJoint.z)]+aWeight.w*uBones[int(aJoint.w)];vec4 pos=s*vec4(aPos,1.);vec3 n=normalize(mat3(uModel)*mat3(s)*aNormal);vLight=(.55+.65*max(dot(n,normalize(vec3(.45,1.,.3))),0.))*uDay;vUV=aUV;gl_Position=uMVP*uModel*pos;}";
  const char*fs="precision mediump float;uniform sampler2D uTex;varying vec2 vUV;varying float vLight;void main(){vec4 t=texture2D(uTex,vUV);gl_FragColor=vec4(t.rgb*vLight,t.a);}";
  GLuint a=compile(GL_VERTEX_SHADER,vs),b=compile(GL_FRAGMENT_SHADER,fs);if(!a||!b)return 0;GLuint p=glCreateProgram();glAttachShader(p,a);glAttachShader(p,b);glBindAttribLocation(p,0,"aPos");glBindAttribLocation(p,1,"aNormal");glBindAttribLocation(p,2,"aUV");glBindAttribLocation(p,3,"aJoint");glBindAttribLocation(p,4,"aWeight");glLinkProgram(p);glDeleteShader(a);glDeleteShader(b);GLint ok;glGetProgramiv(p,GL_LINK_STATUS,&ok);if(!ok){char msg[512];glGetProgramInfoLog(p,sizeof(msg),nullptr,msg);__android_log_print(ANDROID_LOG_ERROR,"AronnoNative","character link %s",msg);glDeleteProgram(p);return 0;}return p;
 }
 bool init(AAssetManager*assets,const char*filename="player.glb"){
  release();if(!assets)return false;AAsset* a=AAssetManager_open(assets,filename,AASSET_MODE_BUFFER);if(!a)return false;auto sz=AAsset_getLength(a);if(sz<=0||sz>10000000){AAsset_close(a);return false;}blob.resize(sz);int read=AAsset_read(a,blob.data(),sz);AAsset_close(a);if(read!=sz)return false;
  cgltf_options opts{};if(cgltf_parse(&opts,blob.data(),blob.size(),&data)!=cgltf_result_success)return false;if(cgltf_load_buffers(&opts,data,nullptr)!=cgltf_result_success||!data->meshes_count||!data->skins_count)return false;
  skin=&data->skins[0];if(skin->joints_count!=24||!skin->inverse_bind_matrices)return false;auto&primitive=data->meshes[0].primitives[0];cgltf_accessor *pos=nullptr,*normal=nullptr,*uv=nullptr,*joints=nullptr,*weights=nullptr;
  for(size_t i=0;i<primitive.attributes_count;i++){auto&x=primitive.attributes[i];switch(x.type){case cgltf_attribute_type_position:pos=x.data;break;case cgltf_attribute_type_normal:normal=x.data;break;case cgltf_attribute_type_texcoord:if(x.index==0)uv=x.data;break;case cgltf_attribute_type_joints:if(x.index==0)joints=x.data;break;case cgltf_attribute_type_weights:if(x.index==0)weights=x.data;break;default:break;}}
  if(!pos||!normal||!uv||!joints||!weights||!primitive.indices||primitive.indices->count>500000)return false;
  std::vector<PlayerVertex> verts;verts.resize(primitive.indices->count);for(size_t i=0;i<verts.size();i++){size_t n=cgltf_accessor_read_index(primitive.indices,i);if(n>=pos->count)return false;auto&v=verts[i];if(!cgltf_accessor_read_float(pos,n,v.p,3)||!cgltf_accessor_read_float(normal,n,v.n,3)||!cgltf_accessor_read_float(uv,n,v.uv,2)||!cgltf_accessor_read_float(joints,n,v.joint,4)||!cgltf_accessor_read_float(weights,n,v.weight,4))return false;for(float j:v.joint)if(j<0||j>=24)return false;}
  if(!primitive.material||!primitive.material->has_pbr_metallic_roughness)return false;auto*tex=primitive.material->pbr_metallic_roughness.base_color_texture.texture;if(!tex||!tex->image||!tex->image->buffer_view)return false;auto*view=tex->image->buffer_view;const unsigned char*bytes=cgltf_buffer_view_data(view);if(!bytes)return false;int w,h,ch;unsigned char* pixels=stbi_load_from_memory(bytes,view->size,&w,&h,&ch,4);if(!pixels)return false;
  glGenTextures(1,&texture);glBindTexture(GL_TEXTURE_2D,texture);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,w,h,0,GL_RGBA,GL_UNSIGNED_BYTE,pixels);glGenerateMipmap(GL_TEXTURE_2D);stbi_image_free(pixels);
  for(size_t i=0;i<data->animations_count;i++){auto&clip=data->animations[i];if(clip.name&&std::string(clip.name)=="walk")walk=&clip;if(clip.name&&std::string(clip.name)=="run")run=&clip;}if(!walk||!run)return false;
  programId=makeProgram();if(!programId)return false;glGenBuffers(1,&vbo);glBindBuffer(GL_ARRAY_BUFFER,vbo);glBufferData(GL_ARRAY_BUFFER,verts.size()*sizeof(PlayerVertex),verts.data(),GL_STATIC_DRAW);count=verts.size();ready=true;return true;
 }
 static void sample(cgltf_animation* clip,float time){
  for(size_t i=0;i<clip->channels_count;i++){auto&ch=clip->channels[i];auto*s=ch.sampler;auto*node=ch.target_node;if(!node||!s||!s->input||!s->output||!s->input->count)continue;
   auto n=s->input->count;float t0=0,t1=0;size_t k=0;while(k+1<n){cgltf_accessor_read_float(s->input,k+1,&t1,1);if(t1>time)break;k++;}cgltf_accessor_read_float(s->input,k,&t0,1);size_t j=std::min(k+1,n-1);cgltf_accessor_read_float(s->input,j,&t1,1);float f=(t1>t0)?std::max(0.f,std::min(1.f,(time-t0)/(t1-t0))):0;int size=ch.target_path==cgltf_animation_path_type_rotation?4:3;float a[4]={},b[4]={};cgltf_accessor_read_float(s->output,k,a,size);cgltf_accessor_read_float(s->output,j,b,size);
   if(size==4&&a[0]*b[0]+a[1]*b[1]+a[2]*b[2]+a[3]*b[3]<0)for(float&x:b)x=-x;
   float out[4];for(int x=0;x<size;x++)out[x]=a[x]+(b[x]-a[x])*f;
   if(size==4){float len=std::sqrt(out[0]*out[0]+out[1]*out[1]+out[2]*out[2]+out[3]*out[3]);if(len>0)for(float&x:out)x/=len;std::copy(out,out+4,node->rotation);node->has_rotation=1;}
   else if(ch.target_path==cgltf_animation_path_type_translation){std::copy(out,out+3,node->translation);node->has_translation=1;}
   else if(ch.target_path==cgltf_animation_path_type_scale){std::copy(out,out+3,node->scale);node->has_scale=1;}
  }
 }
 void draw(const Mat&mvp,float x,float y,float z,float yaw,bool moving,bool running,float dt,float chop=0,float light=1){if(!ready)return;clock+=dt;auto*clip=running?run:walk;float t=moving?std::fmod(clock,running?.625f:1.f):.04f;sample(clip,t);
  if(chop>0){float angle=-2.4f*std::sin((1.f-chop/.72f)*3.14159265f);for(int idx:{21,22}){auto*node=skin->joints[idx];float q[4];std::copy(node->rotation,node->rotation+4,q);float a=angle*(idx==21?1.f:.5f),sn=std::sin(a*.5f),cs=std::cos(a*.5f);node->rotation[0]=q[0]*cs+q[1]*sn;node->rotation[1]=q[1]*cs-q[0]*sn;node->rotation[2]=q[2]*cs+q[3]*sn;node->rotation[3]=q[3]*cs-q[2]*sn;node->has_rotation=1;}}

  float bones[24*16];for(size_t i=0;i<24;i++){Mat world,inv;cgltf_node_transform_world(skin->joints[i],world.v);cgltf_accessor_read_float(skin->inverse_bind_matrices,i,inv.v,16);Mat j=mul(world,inv);std::copy(j.v,j.v+16,bones+i*16);}
  Mat model;float c=std::cos(yaw+3.14159265f),s=std::sin(yaw+3.14159265f);model.v[0]=c;model.v[2]=-s;model.v[5]=1;model.v[8]=s;model.v[10]=c;model.v[12]=x;model.v[13]=y;model.v[14]=z;model.v[15]=1;
  Mat hand;cgltf_node_transform_world(skin->joints[23],hand.v);handWorld=mul(model,hand);
  glUseProgram(programId);glUniform1f(glGetUniformLocation(programId,"uDay"),light);glUniformMatrix4fv(glGetUniformLocation(programId,"uMVP"),1,GL_FALSE,mvp.v);glUniformMatrix4fv(glGetUniformLocation(programId,"uModel"),1,GL_FALSE,model.v);glUniformMatrix4fv(glGetUniformLocation(programId,"uBones[0]"),24,GL_FALSE,bones);glActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,texture);glUniform1i(glGetUniformLocation(programId,"uTex"),0);glBindBuffer(GL_ARRAY_BUFFER,vbo);
  glEnableVertexAttribArray(0);glEnableVertexAttribArray(1);glEnableVertexAttribArray(2);glEnableVertexAttribArray(3);glEnableVertexAttribArray(4);glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(PlayerVertex),(void*)offsetof(PlayerVertex,p));glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,sizeof(PlayerVertex),(void*)offsetof(PlayerVertex,n));glVertexAttribPointer(2,2,GL_FLOAT,GL_FALSE,sizeof(PlayerVertex),(void*)offsetof(PlayerVertex,uv));glVertexAttribPointer(3,4,GL_FLOAT,GL_FALSE,sizeof(PlayerVertex),(void*)offsetof(PlayerVertex,joint));glVertexAttribPointer(4,4,GL_FLOAT,GL_FALSE,sizeof(PlayerVertex),(void*)offsetof(PlayerVertex,weight));glDrawArrays(GL_TRIANGLES,0,count);glDisableVertexAttribArray(3);glDisableVertexAttribArray(4);
 }
};
