#!/usr/bin/env bash
set -euo pipefail
# Set these to Android SDK/NDK paths. This script produces a debug-signed APK.
: "${ANDROID_NDK_HOME:?Set ANDROID_NDK_HOME to the Android NDK root}"
: "${ANDROID_BUILD_TOOLS:?Set ANDROID_BUILD_TOOLS to the SDK build-tools directory}"
: "${ANDROID_PLATFORM_JAR:?Set ANDROID_PLATFORM_JAR to an SDK android.jar}"
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$HERE/out-native"
NDK="$ANDROID_NDK_HOME"
TOOL="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin"
GLUE="$NDK/sources/android/native_app_glue"
rm -rf "$OUT"; mkdir -p "$OUT/lib/arm64-v8a" "$OUT/lib/armeabi-v7a"
for abi in arm64-v8a armeabi-v7a; do
  case "$abi" in arm64-v8a) TARGET=aarch64-linux-android24;; armeabi-v7a) TARGET=armv7a-linux-androideabi24;; esac
  "$TOOL/${TARGET}-clang" -fPIC -O2 -I"$GLUE" -c "$GLUE/android_native_app_glue.c" -o "$OUT/glue-$abi.o"
  "$TOOL/${TARGET}-clang++" -std=c++17 -O2 -fPIC -fvisibility=hidden -I"$GLUE" -I"$HERE/app/src/main/cpp" -c "$HERE/app/src/main/cpp/native_game.cpp" -o "$OUT/main-$abi.o"
  "$TOOL/${TARGET}-clang++" -shared -static-libstdc++ -Wl,-u,ANativeActivity_onCreate -Wl,--build-id=sha1 "$OUT/main-$abi.o" "$OUT/glue-$abi.o" -landroid -llog -lEGL -lGLESv2 -o "$OUT/lib/$abi/libaronno.so"
done
"$ANDROID_BUILD_TOOLS/aapt2" link -o "$OUT/base.apk" -I "$ANDROID_PLATFORM_JAR" --manifest "$HERE/app/src/main/AndroidManifest.xml" --min-sdk-version 24 --target-sdk-version 33
python3 - "$OUT" <<'PY'
import os,sys,zipfile
p=sys.argv[1]
with zipfile.ZipFile(p+'/base.apk','a') as z:
 for abi in ('arm64-v8a','armeabi-v7a'):
  z.write(p+'/lib/'+abi+'/libaronno.so','lib/'+abi+'/libaronno.so',compress_type=zipfile.ZIP_DEFLATED)
 here=os.path.dirname(p)
 for name in ('player.glb','PLAYER_LICENSE.txt','meadow.jpg','wall.jpg','roof.jpg','wood.jpg','leaf.png','grass.png','path.jpg','npc.glb','lobby.jpg'):
  z.write(here+'/app/src/main/assets/'+name,'assets/'+name,compress_type=zipfile.ZIP_DEFLATED)
PY
"$ANDROID_BUILD_TOOLS/zipalign" -f 4 "$OUT/base.apk" "$OUT/aligned.apk"
if [ -z "${ARONNO_KEYSTORE:-}" ]; then
 # Keep this debug key outside the build output so rebuilds remain installable as updates.
 ARONNO_KEYSTORE="${ARONNO_DEBUG_KEY_DIR:-$HOME/.android}/aronno-debug.keystore"
 mkdir -p "$(dirname "$ARONNO_KEYSTORE")"
 if [ ! -f "$ARONNO_KEYSTORE" ]; then
  (umask 077; java sun.security.tools.keytool.Main -genkeypair -keystore "$ARONNO_KEYSTORE" -storepass android -keypass android -alias aronno-debug -keyalg RSA -keysize 2048 -validity 10000 -dname 'CN=Aronno Debug,O=Development,C=US' >/dev/null 2>&1)
 fi
 ARONNO_KEY_ALIAS=aronno-debug;ARONNO_KEY_PASS=android
else
 : "${ARONNO_KEY_ALIAS:?Set ARONNO_KEY_ALIAS}"; : "${ARONNO_KEY_PASS:?Set ARONNO_KEY_PASS}"
fi
"$ANDROID_BUILD_TOOLS/apksigner" sign --ks "$ARONNO_KEYSTORE" --ks-key-alias "$ARONNO_KEY_ALIAS" --ks-pass "pass:$ARONNO_KEY_PASS" --key-pass "pass:$ARONNO_KEY_PASS" --out "$OUT/aronno-cpp-debug.apk" "$OUT/aligned.apk"
"$ANDROID_BUILD_TOOLS/apksigner" verify --verbose "$OUT/aronno-cpp-debug.apk"
echo "APK created: $OUT/aronno-cpp-debug.apk"
