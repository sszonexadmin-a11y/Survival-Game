# Aronno Worlds 0.4.0 — Code Audit, Development Roadmap ও Android Build Status

তারিখ: ৩ নভেম্বর ২০২৬

## 1. যাচাই করা হয়েছে
- ZIP archive-এর 44টি entry ও প্রায় 9.24 MB extracted content পরীক্ষা।
- `README_bn.md`, Android manifest, Gradle/CMake configuration, `build_apk.sh`, C++ headers/source, model ও texture asset তালিকা পর্যালোচনা।
- `tests/world_test.cpp` স্বাভাবিক C++17 build-এ চালানো হয়েছে।
- একই test AddressSanitizer ও UndefinedBehaviorSanitizer সহ চালানো হয়েছে।

## 2. পরীক্ষার ফলাফল
**PASS:** world creation, invalid name rejection, আলাদা world isolation, deterministic seed terrain/tree generation, chunk streaming ও unload/reload, negative coordinates, player/world state save-load, felled tree persistence, shelter persistence, checksum corruption detection, backup restore, backup-ও corrupt হলে load block।

Sanitizer run-এও test সফল হয়েছে; ওই পরীক্ষায় sanitizer error পাওয়া যায়নি।

## 3. APK build status
এই পরিবেশে `ANDROID_NDK_HOME`, Android SDK Build Tools এবং `android.jar` path সেট করা নেই। তাই `build_apk.sh` চালালে প্রথমেই NDK path না পাওয়ার কারণে থেমে যায়। Android APK তৈরি বা install হয়েছে—এমন দাবি করা যাচ্ছে না।

Build করতে প্রয়োজন:
- JDK 17
- Android SDK Platform 33 (`android.jar`)
- Android SDK Build Tools (aapt2, zipalign, apksigner)
- Android NDK (Linux x86_64 host toolchain; API 24 target)
- CMake 3.22.1 (Gradle route ব্যবহার করলে)

Build script চালানোর আগে `ANDROID_NDK_HOME`, `ANDROID_BUILD_TOOLS`, `ANDROID_PLATFORM_JAR` export করতে হবে। Script-টি `bash build_apk.sh` দিয়ে চালানো যায়; ZIP-এ executable bit নাও থাকতে পারে।

## 4. অগ্রাধিকারভিত্তিক Code Review Findings

### P0 — Android build/install gate
- প্রথমে reproducible Android build নিশ্চিত করতে হবে। Gradle route এবং manual script route—দুটির অন্তত একটিকে CI-তে build করাতে হবে।
- APK-তে manifest, native library ABI, asset packaging, package install এবং cold launch যাচাই করতে হবে।
- ARM64 প্রধান target; ARM32 আলাদা করে compile ও install test করতে হবে।

### P1 — Runtime robustness
- EGL/context হারানো, Activity pause/resume, window recreate ও surface resize-এ resource lifecycle পরীক্ষা করতে হবে।
- `loadWorldTextures()`-এ কোনো asset/texture load ব্যর্থ হলে `init()` বর্তমানে error log করে এগিয়ে যায়; আংশিক texture initialization-এর fallback/cleanup নিশ্চিত করা দরকার।
- Player/NPC GLB load ব্যর্থ হলে fallback আচরণ ও resource cleanup বাস্তব ডিভাইসে যাচাই করতে হবে।
- Save/backup write failure, disk full, app force-stop এবং process death-এর পরীক্ষা যোগ করতে হবে।
- Save format version migration পরিকল্পনা করতে হবে; বর্তমানে decode version 1-এ সীমাবদ্ধ।

### P2 — Gameplay integrity
- Chunk boundary-তে collision, tree harvesting, shelter placement এবং নদী/কুয়া interaction-এর automated test যোগ করতে হবে।
- Survival tick, hunger/thirst/health-এর দীর্ঘ সময়ের balance ও offline progression যাচাই করতে হবে।
- Inventory ও item definition-কে data-driven করা উচিত; crafting-এর ভিত্তি তৈরি করতে হবে।
- NPC navigation/interaction এখন প্রাথমিক; pathfinding ও state machine প্রয়োজন।

### P3 — Performance ও polish
- Low/mid-range Android GPU-তে FPS, frame time, memory, thermal throttling মাপতে হবে।
- Texture compression, mipmap memory, mesh batching, LOD, frustum/occlusion culling এবং chunk generation budget পরিমাপের পর অপ্টিমাইজ করতে হবে।
- UI localization, pause/settings, graphics quality, audio, accessibility ও touch-control calibration যোগ করতে হবে।

## 5. Development Roadmap

### Phase A — Build & Stability
1. Gradle/NDK build reproducible করা।
2. Debug APK build ও signature verify।
3. Android 7+ এবং আধুনিক Android-এ install/launch test।
4. EGL lifecycle, texture/model failure fallback, crash logging।
5. Save/load, backup, low-storage ও force-stop tests।

### Phase B — Core Survival
1. পূর্ণ Inventory UI, stack ও item definitions।
2. Crafting recipes ও crafting station।
3. Axe/pickaxe/tool durability, mining ও ore।
4. Food/water/health balance এবং respawn/death flow।

### Phase C — World Expansion
1. Biome system: forest, plains, hills, river, desert ইত্যাদি।
2. Cave/underground ও ore distribution।
3. Structures, villages, loot ও spawn rules।
4. World management: rename, delete, backup/export/import।

### Phase D — Living World
1. Passive animals, resource drops ও simple behavior।
2. Hostile mobs, combat, damage ও spawn control।
3. NPC schedules, dialogue, pathfinding ও village roles।
4. Weather, day/night improvements ও ambient audio।

### Phase E — Release Quality
1. Performance profiling ও device compatibility matrix।
2. Settings, localization, tutorial ও accessibility।
3. Regression tests, crash-free sessions ও save migration।
4. Release keystore দিয়ে signed release APK/AAB।
5. Multiplayer আলাদা architecture milestone হিসেবে; core single-player স্থিতিশীল হওয়ার আগে নয়।

## 6. বর্তমান সীমাবদ্ধতা
এটি 0.4.0 experimental source project। Android device runtime পরীক্ষা হয়নি। Preview image host-rendered; ফোনের screenshot নয়। Lobby artwork gameplay graphics-এর প্রতিনিধিত্ব করে না। README-তে বর্ণিত অনুপস্থিত gameplay features এখনো বাস্তবায়িত নয়।

## 7. পরবর্তী বাস্তব পদক্ষেপ
Android SDK/NDK-সহ Linux/Android Studio build environment-এ Phase A সম্পন্ন করা। APK install ও gameplay smoke test পাস না হওয়া পর্যন্ত এটিকে ফোনে চালানোর জন্য প্রস্তুত release বলা যাবে না।
